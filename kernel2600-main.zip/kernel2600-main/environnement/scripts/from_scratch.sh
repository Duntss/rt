./get_kernel_5.15.167.sh
./compile_kernel_5.15.167.sh
./get_alpine_minirootfs_3.20.0-x86_64.sh
./launch.sh
