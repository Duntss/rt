cd ../linux-5.15.167

# Create .config file
make defconfig # or menuconfig

# Compile kernel and modules
sudo make -j$(nproc)
sudo make modules -j$(nproc)
sudo make modules_install
sudo make install

cd ../scripts
