cd ..

# Create minimal Alpine image
wget https://dl-cdn.alpinelinux.org/alpine/v3.18/releases/x86_64/alpine-minirootfs-3.18.0-x86_64.tar.gz
mkdir alpine_root
tar -xvf alpine-minirootfs-3.18.0-x86_64.tar.gz -C alpine_root

# Create init file
cd alpine_root
cat << EOF > init
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
cd /lib/modules
exec /bin/sh
EOF
chmod +x init

cd ../scripts
