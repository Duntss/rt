cd ..

# Get 5.15.167 linux kernel
wget https://cdn.kernel.org/pub/linux/kernel/v5.x/linux-5.15.167.tar.xz

# Uncompress tar.xz file
tar -xvf linux-5.15.167.tar.xz

cd scripts
