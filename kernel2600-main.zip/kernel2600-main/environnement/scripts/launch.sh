cd ../src
make
if [ $? -ne 0 ]; then
    exit 1
fi
mkdir ../alpine_root/lib/modules
cp *.ko ../alpine_root/lib/modules
make clean
cd ../alpine_root

# Generate initrd.img for QEMU
find . | cpio -o -H newc | gzip > ../initrd.img

cd ..

qemu-system-x86_64 \
    -kernel linux-5.15.167/arch/x86/boot/bzImage \
    -initrd initrd.img \
    -append "console=ttyS0 root=/dev/sr0 rw nokaslr" \
    -nographic
