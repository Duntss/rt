# Environnement kernel

## Ceci est un environnement pour développer et lancer rapidement une machine

- `scripts/get_kernel_5.15.167.sh` : Pour télécharger un kernel Linux 5.15.167 et l'extraire
- `scripts/compile_kernel_5.15.167.sh` : Pour compiler le kernel Linux 5.15.167
- `scripts/get_alpine_minirootfs_3.20.0-x86_64.sh` : Pour récupérer une image Alpine minirootfs (3.20.0)
- `scripts/launch.sh`: Pour compiler les modules, les copier dans `lib/modules` et lancer la machine QEMU
- `scripts/from_scratch.sh` : Pour faire tout ce qui a été dit plus haut, dans l'ordre, en un seul script.

Si c'est la première fois que vous utilisez cet environnement, lancez simplement `scripts/from_scratch.sh`.  

Le dossier `src` contient un Makefile avec un fichier source test d'un module. Libre à vous de modifier comme bon vous semble ce dossier mais il faudra modifier `scripts/launch.sh` pour la compilation si nécessaire.  

## Comment debug avec GDB ?

Dans `scripts/launch.sh`, rajoutez l'option `-S -s` à la fin de QEMU afin de lui dire d'écouter sur le port 1234. Puis lancez le script.  

Dans une autre fenêtre, lancez `gdb linux-5.15.167/vmlinux` puis faites la commande `target remote :1234` pour vous attacher. Ensuite, faites un `continue`.  
Normalement vous verrez QEMU se lancer normalement. Lorsque vous voudrez placer des breakpoints ou analyser la mémoire, faites un `CTRL+C` depuis GDB pour taper des commandes.  

Assurez-vous d'écrire `EXPORT_SYMBOL(votre_fonction)` vers la fin de votre fichier source afin de rendre le symbole visible globalement dans la mémoire (et le voir dans `/proc/kallsyms`).  
Pour placer un breakpoint sur une fonction d'un module en particulier, il faudra insérer le module avec `insmod my_module.ko` pour que les symboles soient chargés en mémoire.  
Puis avec `cat /proc/kallsyms | grep "nom_de_la_fonction"` vous pourrez récupérer l'adresse de la fonction chargée en mémoire.  

Il suffira de placer un `breakpoint` ET un `hardware breakpoint` dessus pour debuguer tranquillement.
